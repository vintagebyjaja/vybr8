import "server-only";
import { formatWhen, spotsLeft } from "@/domain/linkups/linkups";
import { findCity, isOpenAt, project, type Hours } from "@/domain/map/map";
import type { MapData, MapFriend, MapLinkup, MapVenue } from "@/domain/map/pins";
import { createClient } from "@/lib/supabase/server";
import type { Viewer } from "@/server/auth";
import { getFeed } from "@/server/posts";

/** Everything the Vybe Map shows for one city. All reads run under the viewer's RLS. */
export async function getMapData(citySlug: string, viewer: Viewer | null): Promise<MapData> {
  const city = findCity(citySlug);
  const supabase = await createClient();
  const now = new Date();

  const { data: locs } = await supabase
    .from("business_locations")
    .select("id, latitude, longitude, timezone, business:businesses ( id, slug, name, kind, price_level, logo_url, is_demo ), hours:business_hours ( weekday, opens_at, closes_at )")
    .eq("city_slug", city.slug)
    .not("latitude", "is", null)
    .limit(300);

  type Loc = {
    id: string; latitude: string | number; longitude: string | number; timezone: string;
    business: { id: string; slug: string; name: string; kind: string; price_level: number | null; logo_url: string | null; is_demo: boolean } | null;
    hours: { weekday: number; opens_at: string; closes_at: string }[];
  };
  const locations = ((locs ?? []) as unknown as Loc[]).filter((l) => l.business);
  const businessIds = [...new Set(locations.map((l) => l.business!.id))];

  const [feed, linkupRows, statusRows, mine] = await Promise.all([
    getFeed({ kind: "businesses", businessIds }),
    supabase
      .from("linkups")
      .select("id, title, occasion, starts_at, ends_at, capacity, is_alcoholic, open_to_new_friends, meet_point, business:businesses ( id, name )")
      .eq("city_slug", city.slug)
      .eq("status", "active")
      .gt("ends_at", now.toISOString())
      .lt("starts_at", new Date(now.getTime() + 7 * 86_400_000).toISOString())
      .order("starts_at")
      .limit(40),
    viewer
      ? supabase
          .from("vybe_statuses")
          .select("user_id, intent, note, business_id, expires_at, profile:profiles!vybe_statuses_user_id_fkey ( username, display_name )")
          .eq("city_slug", city.slug)
          .gt("expires_at", now.toISOString())
          .neq("user_id", viewer.id)
      : Promise.resolve({ data: [] }),
    viewer ? supabase.from("vybe_statuses").select("intent, note, expires_at").eq("user_id", viewer.id).gt("expires_at", now.toISOString()).maybeSingle() : Promise.resolve({ data: null }),
  ]);

  // Latest photo per business.
  const photoBy = new Map<string, MapVenue["photo"]>();
  for (const p of feed.posts) {
    const bizId = locations.find((l) => l.business!.slug === p.business?.slug)?.business!.id;
    if (bizId && !photoBy.has(bizId) && p.photos[0]) {
      photoBy.set(bizId, { src: p.photos[0].src, alt: p.photos[0].alt, rating: p.rating, postId: p.id, isAlcoholic: p.isAlcoholic });
    }
  }

  const posByBusiness = new Map<string, { x: number; y: number }>();
  const venues: MapVenue[] = locations.map((l) => {
    const { x, y } = project(Number(l.latitude), Number(l.longitude), city.bounds);
    const b = l.business!;
    if (!posByBusiness.has(b.id)) posByBusiness.set(b.id, { x, y });
    const hours: Hours[] = l.hours.map((h) => ({ weekday: h.weekday, opensAt: h.opens_at, closesAt: h.closes_at }));
    return {
      id: l.id, businessSlug: b.slug, name: b.name, kind: b.kind, priceLevel: b.price_level, logoUrl: b.logo_url, isDemo: b.is_demo,
      x, y, openNow: hours.length ? isOpenAt(hours, l.timezone, now) : null, photo: photoBy.get(b.id) ?? null,
    };
  });

  type LinkupRow = { id: string; title: string; occasion: string; starts_at: string; capacity: number; is_alcoholic: boolean; open_to_new_friends: boolean; meet_point: string | null; business: { id: string; name: string } | null };
  const lrows = (linkupRows.data ?? []) as unknown as LinkupRow[];
  const { data: spots } = lrows.length ? await supabase.rpc("linkup_spots", { p_ids: lrows.map((l) => l.id) }) : { data: [] };
  const takenBy = new Map(((spots ?? []) as { linkup_id: string; taken: number }[]).map((s) => [s.linkup_id, s.taken]));
  const linkups: MapLinkup[] = lrows.map((l, i) => {
    const pos = l.business ? posByBusiness.get(l.business.id) : undefined;
    // Link Ups without a listed place sit on a ring around the center so they don't overlap.
    const angle = (i / Math.max(1, lrows.length)) * Math.PI * 2;
    const fallback = { x: 50 + Math.cos(angle) * 22, y: 50 + Math.sin(angle) * 18 };
    return {
      id: l.id, title: l.title, occasion: l.occasion, when: formatWhen(new Date(l.starts_at), findCity(city.slug).timezone),
      ...(pos ?? fallback), spotsLeft: spotsLeft(l.capacity, takenBy.get(l.id) ?? 1), capacity: l.capacity,
      isAlcoholic: l.is_alcoholic, openToNewFriends: l.open_to_new_friends, venueName: l.business?.name ?? l.meet_point,
    };
  });

  type StatusRow = { user_id: string; intent: MapFriend["intent"]; note: string | null; business_id: string | null; profile: { username: string; display_name: string | null } | null };
  const friends: MapFriend[] = ((statusRows.data ?? []) as unknown as StatusRow[]).map((s) => {
    const pos = s.business_id ? posByBusiness.get(s.business_id) : undefined;
    return {
      userId: s.user_id, username: s.profile?.username ?? "friend", name: s.profile?.display_name ?? s.profile?.username ?? "Friend",
      intent: s.intent, note: s.note,
      venueName: s.business_id ? (locations.find((l) => l.business!.id === s.business_id)?.business!.name ?? null) : null,
      x: pos?.x ?? null, y: pos?.y ?? null,
    };
  });

  const m = mine.data as { intent: MapFriend["intent"]; note: string | null; expires_at: string } | null;
  return {
    city: { slug: city.slug, name: city.name, region: city.region },
    venues, linkups, friends,
    myStatus: m ? { intent: m.intent, note: m.note, expiresAt: m.expires_at } : null,
  };
}

/** The city the viewer last picked, else Charlotte. */
export async function getViewerCity(viewer: Viewer | null, override?: string | null): Promise<string> {
  if (override) return findCity(override).slug;
  if (!viewer) return findCity(null).slug;
  const supabase = await createClient();
  const { data } = await supabase.from("user_settings").select("city_slug").eq("user_id", viewer.id).maybeSingle();
  return findCity(data?.city_slug as string | null).slug;
}
